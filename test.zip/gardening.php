<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Finder</title>
    <link rel="stylesheet" href="styles.css">

    <script src="scripts.js" async></script>
</head>

<body>
    <?php 
    include 'header.php';
    ?>


    <footer>
        <p>The footer</p>
    </footer>


</body>

</html>