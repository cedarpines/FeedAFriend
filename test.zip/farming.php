<?php 
include 'header.php';
?>

    <script src="scripts.js" async></script>
</head>

<body>
    <?php 
    

    include 'loadPost.php';
    ?>

    <footer>
        <p>The footer</p>
    </footer>
</body>

</html>