<?php
include "start.php";
if(!isset($_SESSION["ID"])){
    header("location: loginForm.php");
    exit();
}
$test = $conn->query("SELECT * FROM PLEDGELIST WHERE PID = '$_GET[post]'
 AND UID = '$_SESSION[ID]'");
if($test->num_rows>0){
    echo '<p>You have already pledge to this post.</p> 
    <a href="unpledge.php?post='.$_GET["post"].'">button>unpledge?</button></a>';
}else{

if(isset($_GET["confirmed"]) && $_GET["confirmed"]){
    $conn->query("INSERT INTO PLEDGELIST (UID, PID) 
VALUES ('$_SESSION[ID]', '$_GET[post]')");
    $conn->query("UPDATE FARMPOST SET currentPledge = currentPledge + 1 WHERE PID = '$_GET[post]'");
    header("location: farming.php");
    exit();
}

echo '
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Food Finder</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <h1>
            Confirm your pledge to:
        </h1>';
        
        $result = $conn->query("SELECT * FROM FARMPOST WHERE PID = '$_GET[post]'");
        $row = $result->fetch_assoc();
        $result2 = $conn->query("SELECT * FROM USER WHERE ID = '$row[UID]'");
        $row2 = $result2->fetch_assoc();
        echo '<div class="forum-post">
            <div class="row1">
                Username <a href="farming.php?filter='.$row["UID"].'">'.$row2["username"].'</a>
            </div>
            <div class="row2">
                Post Title '.$row["title"].'
            </div>
            <div class="row3-1">
                IMAGE
                <img src="images/'.$row["image"].".".$row["imageExt"].'"
                    alt="">  
            </div>
            <div class="row3-2">
                DESCRIPTION
                <p>'.$row["text"].'</p>
            </div>
            <div class="row3">
                Progress bar
                '.$row["currentPledge"] . ' out of '.$row["targetPledge"].'
            </div>'; 
echo '  
        <a href="pledge.php?post='. $_GET["post"] . '&confirmed=true"><button>confirm</button></a>
            <a href="farming.php"><button>return</button></a>
        </form>

    </body>

</html>
';
}
?>