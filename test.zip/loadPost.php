<?php
include 'start.php';


if(!isset($_GET["filterPost"])){
$result = $conn->query("SELECT * FROM FARMPOST ORDER BY currentPledge/targetPledge DESC");
}else{
    
    $result = $conn->query("SELECT * FROM FARMPOST WHERE UID = '$_GET[filterPost]' ORDER BY
    currentPledge/targetPledge DESC");
}
if(!isset($_GET["page"])){
    $_GET["page"]=1;
}
$offset = ($_GET["page"] - 1 )*5;
for($i = 0; $i<$offset; $i++){
    $row = $result->fetch_assoc();
}

if(isset($_SESSION["typeUser"]) && $_SESSION["typeUser"]== "farmer"){
echo '<a href="postForm.php"><button>New post</button></a>';
}

for($x = 0; $x<5; $x++){
    if($row = $result->fetch_assoc()){
    $result2 = $conn->query("SELECT * FROM USER WHERE ID = '$row[UID]'");
    $row2 = $result2->fetch_assoc();
    echo '
        <div class="forum-post">
            <div class="row1">
                Username <a href="farming.php?filter='.$row["UID"].'">'.$row2["username"].'</a>
            </div>
            <div class="row2">
                Post Title '.$row["title"].'
            </div>
            <div class="row3-1">
                IMAGE
                <img src="images/'.$row["image"].".".$row["imageExt"].'"
                    alt="">  
            </div>
            <div class="row3-2">
                DESCRIPTION
                <p>'.$row["text"].'</p>
            </div>
            <div class="row3">
                Progress bar
                '.$row["currentPledge"] . ' out of '.$row["targetPledge"].'
            </div>
            <a href="pledge.php?post='.$row["PID"].'"><button>Pledge</button></a>';
            if($row["UID"] = $_SESSION["ID"]){
                echo '<a href="deletePost.php?post='.$row["PID"].'"><button>Delete</button></a>';
            }
        echo '</div>
        </div>';
    }
    echo '</div>';

}
if(!($_GET["page"]==1)){
    echo '<a href="farming.php?page='.($_GET["page"]-1).'"><button>Previous</button></a>';
}
if($row = $result->fetch_assoc()){
    echo '<a href="farming.php?page='.($_GET["page"]+1).'"><button>Next</button></a>';
}

?>